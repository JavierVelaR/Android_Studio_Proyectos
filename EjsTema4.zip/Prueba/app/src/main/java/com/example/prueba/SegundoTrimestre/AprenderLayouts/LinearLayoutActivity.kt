package com.example.prueba.SegundoTrimestre.AprenderLayouts

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.prueba.R

class LinearLayoutActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_linear_layout)
    }
}