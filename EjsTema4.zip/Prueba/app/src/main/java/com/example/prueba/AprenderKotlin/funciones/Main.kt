package funciones

fun main() {
    //piedraPapelTijera(nAleatorio())
    //fibonacci(10)

    val dado:Dado = Dado(6)
    dado.jugar()

}